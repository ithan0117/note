package model.pojo;

import java.sql.Timestamp;

public class MemberBean {
	private Integer id;
	private String account;
	private String password;
	private String nickname;
	private Timestamp createTime;
	private Boolean pass;
	private String sessionId;
	
	public MemberBean() {
	}

	public MemberBean(Integer id, String account, String password,
			String nickname, Timestamp createTime, Boolean pass,
			String sessionId) {
		this.id = id;
		this.account = account;
		this.password = password;
		this.nickname = nickname;
		this.createTime = createTime;
		this.pass = pass;
		this.sessionId = sessionId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public Timestamp getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}

	public Boolean getPass() {
		return pass;
	}

	public void setPass(Boolean pass) {
		this.pass = pass;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
}
