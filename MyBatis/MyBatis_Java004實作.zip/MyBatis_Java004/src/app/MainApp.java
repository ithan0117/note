package app;

import org.apache.ibatis.session.SqlSession;

public class MainApp {

	public static void main(String[] args) {
		SqlSession session;
	}
}
